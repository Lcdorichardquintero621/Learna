package com.amigo.learna

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang: String? = null
    private val queue = ArrayDeque<Triple<String, String, Float>>()
    private var speaking = false
    private var curId = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { if (id == curId) runOnUiThread { pump() } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { if (id == curId) runOnUiThread { pump() } }
            })
            setLang("en")
        }
    }

    private fun setLang(l: String) {
        val tags = if (l == "es") listOf("es-ES", "es-US", "es-MX", "es") else listOf("en-US", "en")
        for (t in tags) {
            val r = tts?.setLanguage(Locale.forLanguageTag(t)) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (r >= TextToSpeech.LANG_AVAILABLE) return
        }
    }

    private fun pump() {
        val n = queue.removeFirstOrNull()
        if (n == null) { speaking = false; return }
        speaking = true
        setLang(n.second)
        tts?.setSpeechRate(n.third)
        curId = "u" + System.nanoTime()
        val r = tts?.speak(n.first, TextToSpeech.QUEUE_FLUSH, null, curId)
        if (r != TextToSpeech.SUCCESS) pump()
    }

    private fun stopTts() {
        queue.clear()
        tts?.stop()
        speaking = false
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun recIntent(lang: String) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    private fun fallback(lang: String) {
        try {
            startActivityForResult(recIntent(lang).putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora"), 77)
        } catch (e: ActivityNotFoundException) {
            js("onSpeech('','no-service')")
        }
    }

    private fun startListening(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        stopTts()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fallback(lang)
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                js("onSpeech(${JSONObject.quote(t)},'')")
            }
            override fun onError(error: Int) {
                when (error) {
                    6, 7 -> js("onSpeech('','err$error')")
                    9 -> js("onSpeech('','perm')")
                    else -> fallback(lang)
                }
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(recIntent(lang))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            val t = if (resultCode == RESULT_OK)
                data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "" else ""
            js(if (t.isNotEmpty()) "onSpeech(${JSONObject.quote(t)},'')" else "onSpeech('','err7')")
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        val l = pendingLang
        pendingLang = null
        if (l != null) {
            if (res.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening(l)
            else js("onSpeech('','perm')")
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun speakLang(text: String, rate: Float, lang: String, flush: Boolean) {
            runOnUiThread {
                if (!ttsReady) return@runOnUiThread
                if (flush) stopTts()
                queue.addLast(Triple(text, lang, rate))
                if (!speaking) pump()
            }
        }

        @JavascriptInterface
        fun speak(text: String, rate: Float) = speakLang(text, rate, "en", true)

        @JavascriptInterface
        fun stopSpeak() { runOnUiThread { stopTts() } }

        @JavascriptInterface
        fun listen(lang: String) { runOnUiThread { startListening(lang) } }

        @JavascriptInterface
        fun chat(id: Int, key: String, body: String) {
            Thread {
                try {
                    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 20000
                    c.readTimeout = 60000
                    c.doOutput = true
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-api-key", key)
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.outputStream.use { it.write(body.toByteArray()) }
                    val code = c.responseCode
                    val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                    if (code in 200..299) {
                        val arr = JSONObject(txt).getJSONArray("content")
                        val sb = StringBuilder()
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            if (o.optString("type") == "text") sb.append(o.getString("text"))
                        }
                        js("onChat($id,true,${JSONObject.quote(sb.toString())})")
                    } else {
                        js("onChat($id,false,${JSONObject.quote("Error $code: $txt")})")
                    }
                } catch (e: Exception) {
                    js("onChat($id,false,${JSONObject.quote(e.message ?: "Sin conexión")})")
                }
            }.start()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()") { r -> if (r != "true") finish() }
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }
}
