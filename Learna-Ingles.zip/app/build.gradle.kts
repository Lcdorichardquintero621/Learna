plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.amigo.learna"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.amigo.learna"
        minSdk = 24
        targetSdk = 34
        versionCode = 16
        versionName = "1.6"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("learna.keystore")
            storePassword = "learna123"
            keyAlias = "learna"
            keyPassword = "learna123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
